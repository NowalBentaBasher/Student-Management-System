<footer class="footer bg-light border-top fixed-bottom">
  <div class="footer-bottom">
    <p>Copyright © IIT NSTU 2020 | Designed and Developed by <b><a href="about.php">IIT 1st batch</a></b></p>
  </div>
</footer>
