# Student Management System

Student Management System manages student information like

* Student List
* Registration of new Student
* Student attendance
* Student CT exam marks
* Student Results
* Class routine
