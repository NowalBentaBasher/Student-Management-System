<?php
	// Setting variables for page
	$title = 'CT Result';

	require_once('header.php');
?>

<body id="page-top" data-spy="scroll" data-target=".fixed-top">
	<!-- Navigation bar -->
	<?php require_once('navbar.php'); ?>

	<!-- Body -->
	<div class="container">
		<div class="row">
			<div class="col mt-2 pt-2 pr-3 text-justify">
				<h1>CT Result</h1>
				<p>Add CT exam result</p>
				<div class="container mt-5">
					<form class="mt-3" action="" method="post" enctype="multipart/form-data">
						<div class="form-group">
							<label for="csv">Upload your routine as csv</label>
							<input type="file" class="form-control border-0" name="csv" id="csv" required>
						</div>
						<div class="row">
							<div class="form-group ml-2 mr-2">
								<label for="session">Select Session</label>
								<select class="form-control custom-select" name="session" id="session" required>
									<option value="" selected disabled hidden>None</option>
									<?php
										$query = "SELECT session_name FROM session_info WHERE department_info_iddepartment_info=? ORDER BY session_name";
										try {
											$stmt = $connection->prepare($query);
											$stmt->bind_param("i", $_SESSION['deptid']);
											$stmt->execute();
											$result = $stmt->get_result();
											while ($row = $result->fetch_row()) {
												echo "<option value='$row[0]'>$row[0]</option>";	
											}
											$stmt->close();
										} catch (Exception $ex) {}
									?>
								</select>
							</div>
							<div class="form-group ml-2 mr-2">
								<label for="term">Select Term</label>
								<select class="form-control custom-select" name="term" id="term" required>
									<option value="" selected disabled hidden>None</option>
									<option value="1">1</option>
									<option value="2">2</option>
								</select>
							</div>
							<div class="form-group ml-2 mr-2">
								<label for="course_code">Select Couese Code</label>
								<select class="form-control custom-select" name="course_code" id="course_code" required>
									<option value="" selected disabled hidden>None</option>
									<!-- Populate course code by slection change event of session and term -->
									<option value="CSE3101">CSE3101</option>
									<option value="CSE3103">CSE3103</option>
									<option value="CSE3104">CSE3104</option>
									<option value="CSE3105">CSE3105</option>
									<option value="CSE3106">CSE3106</option>
								</select>
							</div>
						</div>

						<div class="row mt-4 mb-2">
							<div class="form-group ml-2 mr-2">
								<input type="submit" name="submit" id="submit" class="btn btn-primary" value="Upload CT Result">
							</div>
							<div class="form-group mb-3 ml-2 mr-2">
								<a href="download.php?link=uploads/ctexams/template_ctexam.csv" target="_blank"
									class="btn btn-secondary" name="downloadTemplate">Download Template CSV</a>
							</div>
						</div>

						<span id="status"><b>N.B. If a result sheet already exists then it will replace the old one.</b></span>
						<?php
							if (isset($_SESSION['sessdata'])) {
								$sessdata = $_SESSION['sessdata'];
								?>
						<div class="row mt-2 pt-2 pl-2">
							<span class="text-<?php echo $sessdata['type']; ?>">
								<b><?php echo $sessdata['message']; ?></b>
							</span>
						</div>
						<?php
								unset($_SESSION['sessdata']);
							}
						?>
					</form>
				</div>
			</div>
		</div>
	</div>

	<!-- Footer -->
	<?php require_once('footer.php'); ?>
</body>

</html>