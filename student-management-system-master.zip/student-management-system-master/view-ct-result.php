<?php
	// Setting variables for page
	$title = 'CT Result';

	require_once('header.php');
?>

<body id="page-top" data-spy="scroll" data-target=".fixed-top">
	<!-- Navigation bar -->
	<?php require_once('navbar.php'); ?>

	<!-- Body -->
	<div class="container">
		<div class="row">
			<div class="col mt-2 pt-2 pr-3 text-justify">
				<h1>CT Result</h1>
				<p>See CT exams results</p>
				<div class="container mt-5">
					<form action="#result_table" method="post">
						<div class="row">
							<div class="form-group ml-2 mr-2">
								<label for="session">Select Session</label>
								<select class="form-control custom-select" name="session" id="session" required>
									<option value="" selected disabled hidden>None</option>
									<?php
										$query = "SELECT session_name FROM session_info WHERE department_info_iddepartment_info=? ORDER BY session_name";
										try {
											$stmt = $connection->prepare($query);
											$stmt->bind_param("i", $_SESSION['deptid']);
											$stmt->execute();
											$result = $stmt->get_result();
											while ($row = $result->fetch_row()) {
												echo "<option value='$row[0]'>$row[0]</option>";	
											}
											$stmt->close();
										} catch (Exception $ex) {}
									?>
								</select>
							</div>
							<div class="form-group ml-2 mr-2">
								<label for="term">Select Term</label>
								<select class="form-control custom-select" name="term" id="term" required>
									<option value="" selected disabled hidden>None</option>
									<option value="1">1</option>
									<option value="2">2</option>
								</select>
							</div>
							<div class="form-group ml-2 mr-2">
								<label for="course_code">Select Couese Code</label>
								<select class="form-control custom-select" name="course_code" id="course_code" required>
									<option value="" selected disabled hidden>None</option>
									<!-- Populate course code by slection change event of session and term -->
									<option value="CSE3101">CSE3101</option>
									<option value="CSE3103">CSE3103</option>
									<option value="CSE3104">CSE3104</option>
									<option value="CSE3105">CSE3105</option>
									<option value="CSE3106">CSE3106</option>
								</select>
							</div>
						</div>

						<div class="form-group">
							<button type="submit" name="submitSessionTermCourse" id="submitSessionTermCourse"
								class="btn btn-primary">Submit Query
							</button>
						</div>
					</form>
				</div>

				<div id="result_table" class="container mt-5">
					<p id="status"></p>
					<div class="row">
						<table class="table table-stripped table-bordered">
							<thead class="thead-light">
								<tr>
									<th>Name</th>
									<th>CT1</th>
									<th>CT2</th>
									<th>CT3</th>
									<th>Total</th>
									<th>Best two Avg.</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>STUDENT 1</td>
									<td>--</td>
									<td>--</td>
									<td>--</td>
									<td>--</td>
									<td>--</td>
								</tr>
								<tr>
									<td>STUDENT 2</td>
									<td>--</td>
									<td>--</td>
									<td>--</td>
									<td>--</td>
									<td>--</td>
								</tr>
								<tr>
									<td>STUDENT 3</td>
									<td>--</td>
									<td>--</td>
									<td>--</td>
									<td>--</td>
									<td>--</td>
								</tr>
								<tr>
									<td>STUDENT 4</td>
									<td>--</td>
									<td>--</td>
									<td>--</td>
									<td>--</td>
									<td>--</td>
								</tr>
								<tr>
									<td>STUDENT 5</td>
									<td>--</td>
									<td>--</td>
									<td>--</td>
									<td>--</td>
									<td>--</td>
								</tr>
								<tr>
									<td>STUDENT 6</td>
									<td>--</td>
									<td>--</td>
									<td>--</td>
									<td>--</td>
									<td>--</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Footer -->
	<?php require_once('footer.php'); ?>
</body>

</html>